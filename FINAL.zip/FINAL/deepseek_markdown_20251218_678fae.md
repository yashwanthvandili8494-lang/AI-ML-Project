# Real-time AI Backend with WebSockets & Supabase

A high-performance, asynchronous Python backend for real-time conversational AI sessions with WebSocket streaming, LLM interactions, and Supabase persistence.

## Features

- **Real-time WebSocket Communication**: Bi-directional streaming with immediate response
- **Complex LLM Interactions**: Function calling, multi-step routing, state management
- **Supabase Integration**: Async data persistence with PostgreSQL
- **Post-Session Processing**: Automatic summary generation after session ends
- **Session Management**: Full lifecycle from creation to termination

## Architecture
