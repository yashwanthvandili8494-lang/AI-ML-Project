from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime
from uuid import UUID

class SessionCreate(BaseModel):
    user_id: str
    title: Optional[str] = None

class SessionUpdate(BaseModel):
    end_time: Optional[datetime] = None
    duration: Optional[int] = None
    summary: Optional[str] = None
    status: Optional[str] = None

class EventCreate(BaseModel):
    session_id: str
    event_type: str  # 'user_message', 'ai_response', 'tool_call', 'tool_result'
    content: str
    tool_name: Optional[str] = None
    tool_args: Optional[Dict[str, Any]] = None
    tool_result: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class WebSocketMessage(BaseModel):
    type: str  # 'user_message', 'system', 'error'
    content: str
    metadata: Optional[Dict[str, Any]] = None

class ToolCall(BaseModel):
    name: str
    args: Dict[str, Any]

class LLMResponse(BaseModel):
    content: str
    tool_calls: Optional[List[ToolCall]] = None