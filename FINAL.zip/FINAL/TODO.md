# TODO: Add Login Page and User Registration to Movie Recommender App

- [x] Import necessary modules: from flask import session, redirect, url_for
- [x] Set up Flask app secret key for sessions
- [x] Add /login route (GET for form, POST for processing) with hardcoded credentials (username: 'admin', password: 'password')
- [x] Protect the home route: check if logged in, else redirect to /login
- [x] Add /logout route to clear session and redirect to /login
- [x] Update the home template to include a logout link
- [x] Test the app to ensure login/logout works correctly
- [x] Import werkzeug.security for password hashing
- [x] Create "users" collection in MongoDB
- [x] Add /register route (GET for form, POST for processing) with username and password fields
- [x] Store hashed password and username in database, ensure unique usernames
- [x] Update /login route to check credentials against database
- [x] Add registration link to login page
- [ ] Test registration and login with database-stored users
