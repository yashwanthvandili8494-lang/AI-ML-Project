import sqlite3
from datetime import datetime

def create_session(session_id, user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sessions
                 (session_id TEXT PRIMARY KEY, user_id TEXT, created_at TEXT)''')
    c.execute("INSERT OR REPLACE INTO sessions VALUES (?, ?, ?)",
              (session_id, user_id, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def log_event(session_id, event_type, content):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS events
                 (id INTEGER PRIMARY KEY, session_id TEXT, event_type TEXT, content TEXT, timestamp TEXT)''')
    c.execute("INSERT INTO events (session_id, event_type, content, timestamp) VALUES (?, ?, ?, ?)",
              (session_id, event_type, content, datetime.now().isoformat()))
    conn.commit()
    conn.close()
