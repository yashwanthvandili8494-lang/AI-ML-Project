import json
import asyncio
from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict
from .session_manager import SessionManager
from .models import WebSocketMessage

class ConnectionManager:
    def __init__(self):
        self.session_manager = SessionManager()
        self.active_connections: Dict[str, WebSocket] = {}
    
    async def connect(self, websocket: WebSocket, session_id: str):
        await websocket.accept()
        self.active_connections[session_id] = websocket
    
    def disconnect(self, session_id: str):
        if session_id in self.active_connections:
            del self.active_connections[session_id]
    
    async def send_message(self, websocket: WebSocket, message: WebSocketMessage):
        await websocket.send_json(message.dict())
    
    async def handle_websocket(self, websocket: WebSocket, session_id: str = None):
        """Handle WebSocket connection"""
        
        # Generate new session if not provided
        if not session_id:
            session_data = await self.session_manager.create_new_session("anonymous", websocket)
            session_id = session_data["session_id"]
        else:
            # Check if session exists
            session = await self.session_manager.db.get_session(session_id)
            if not session:
                await self.send_message(websocket, WebSocketMessage(
                    type="error",
                    content="Session not found"
                ))
                return
        
        await self.connect(websocket, session_id)
        
        try:
            await self.send_message(websocket, WebSocketMessage(
                type="system",
                content=f"Connected to session: {session_id}",
                metadata={"session_id": session_id}
            ))
            
            while True:
                # Receive message from client
                data = await websocket.receive_text()
                message_data = json.loads(data)
                
                if message_data.get("type") == "user_message":
                    user_message = message_data["content"]
                    
                    # Stream AI response
                    async for chunk in self.session_manager.handle_user_message(session_id, user_message):
                        await self.send_message(websocket, WebSocketMessage(
                            type="ai_chunk",
                            content=chunk
                        ))
                    
                    # Send completion signal
                    await self.send_message(websocket, WebSocketMessage(
                        type="ai_response_complete",
                        content=""
                    ))
                
                elif message_data.get("type") == "end_session":
                    break
        
        except WebSocketDisconnect:
            print(f"Client disconnected from session {session_id}")
        
        finally:
            self.disconnect(session_id)
            # Trigger post-session processing
            asyncio.create_task(self.session_manager.end_session(session_id))