import asyncio
import os
import openai

openai.api_key = os.getenv('OPENAI_API_KEY')

async def handle_llm_interaction(conversation, session_id):
    if not os.getenv('OPENAI_API_KEY'):
        # Fallback to simulation if no API key
        response = "Hello, this is a simulated AI response because no OpenAI API key is set."
        for token in response.split():
            yield token + " "
            await asyncio.sleep(0.1)
        return

    try:
        # Use OpenAI API for real response (old version)
        messages = [{"role": msg["role"], "content": msg["content"]} for msg in conversation]
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=messages,
            stream=True
        )
        for chunk in response:
            if chunk.choices[0].delta.get('content'):
                yield chunk.choices[0].delta['content']
                await asyncio.sleep(0.01)  # Small delay for streaming
    except Exception as e:
        # Fallback on error
        response = f"Sorry, there was an error with the AI: {str(e)}. This is a simulated response."
        for token in response.split():
            yield token + " "
            await asyncio.sleep(0.1)
