from quart import Quart, websocket, send_file
import asyncio
from database import create_session, log_event
from llm import handle_llm_interaction
from tasks import process_session_summary
import json

app = Quart(__name__)

# In-memory storage for conversation state per session
conversation_states = {}

@app.route('/')
async def index():
    return await send_file('index.html')

@app.websocket('/session/<session_id>')
async def session_ws(session_id):
    user_id = websocket.args.get('user_id', 'default_user')
    
    # Create session in DB
    create_session(session_id, user_id)
    
    # Initialize conversation state
    conversation_states[session_id] = [
        {"role": "system", "content": "You are a helpful AI assistant with access to tools. Provide detailed, comprehensive responses with multiple sentences when appropriate. Be thorough and informative in your answers."}
    ]
    
    try:
        while True:
            # Receive user message
            data = await websocket.receive()
            user_message = json.loads(data)['message']
            
            # Log user message
            log_event(session_id, "user_message", user_message)
            
            # Add to conversation
            conversation_states[session_id].append({"role": "user", "content": user_message})
            
            # Handle LLM interaction and stream response
            ai_response = ""
            async for token in handle_llm_interaction(conversation_states[session_id], session_id):
                ai_response += token
                await websocket.send(json.dumps({"token": token}))
            
            # Log AI response
            log_event(session_id, "ai_response", ai_response)
            
            # Add to conversation
            conversation_states[session_id].append({"role": "assistant", "content": ai_response})
            
    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        # On disconnect, trigger post-session processing
        asyncio.create_task(process_session_summary(session_id))
        # Clean up state
        if session_id in conversation_states:
            del conversation_states[session_id]

if __name__ == '__main__':
    app.run()
