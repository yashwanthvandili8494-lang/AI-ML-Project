import os
from supabase import create_client, Client
from dotenv import load_dotenv
import json
from typing import Dict, Any, Optional
from datetime import datetime

load_dotenv()

class DatabaseManager:
    def __init__(self):
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_key = os.getenv("SUPABASE_KEY")
        
        if not supabase_url or not supabase_key:
            raise ValueError("SUPABASE_URL and SUPABASE_KEY must be set in environment variables")
        
        self.supabase: Client = create_client(supabase_url, supabase_key)
    
    async def create_session(self, user_id: str, title: Optional[str] = None) -> Dict[str, Any]:
        """Create a new session record"""
        session_data = {
            "user_id": user_id,
            "title": title or f"Session {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "status": "active"
        }
        
        response = self.supabase.table("sessions").insert(session_data).execute()
        return response.data[0] if response.data else None
    
    async def add_event(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """Add an event to the session log"""
        response = self.supabase.table("session_events").insert(event_data).execute()
        return response.data[0] if response.data else None
    
    async def get_session_events(self, session_id: str, limit: int = 100) -> list:
        """Get events for a session"""
        response = (self.supabase.table("session_events")
                   .select("*")
                   .eq("session_id", session_id)
                   .order("timestamp", desc=False)
                   .limit(limit)
                   .execute())
        return response.data
    
    async def update_session(self, session_id: str, update_data: Dict[str, Any]) -> Dict[str, Any]:
        """Update session metadata"""
        response = (self.supabase.table("sessions")
                   .update(update_data)
                   .eq("session_id", session_id)
                   .execute())
        return response.data[0] if response.data else None
    
    async def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session by ID"""
        response = (self.supabase.table("sessions")
                   .select("*")
                   .eq("session_id", session_id)
                   .single()
                   .execute())
        return response.data if response.data else None