from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import uuid
from .websocket import ConnectionManager
from .session_manager import SessionManager

app = FastAPI(title="Real-time AI Backend", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize managers
connection_manager = ConnectionManager()
session_manager = SessionManager()

@app.get("/")
async def root():
    return {"message": "Real-time AI Backend API", "status": "running"}

@app.post("/sessions/create")
async def create_session():
    """Create a new session"""
    session_id = str(uuid.uuid4())
    session = await session_manager.create_new_session("user_" + session_id[:8])
    return {"session_id": session["session_id"], "message": "Session created"}

@app.get("/sessions/{session_id}")
async def get_session(session_id: str):
    """Get session details"""
    session = await session_manager.db.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session

@app.get("/sessions/{session_id}/events")
async def get_session_events(session_id: str, limit: int = 50):
    """Get session events"""
    events = await session_manager.db.get_session_events(session_id, limit)
    return {"events": events, "count": len(events)}

@app.websocket("/ws/session/{session_id}")
async def websocket_session(websocket: WebSocket, session_id: str = None):
    """WebSocket endpoint for real-time conversation"""
    await connection_manager.handle_websocket(websocket, session_id)

@app.websocket("/ws/session")
async def websocket_new_session(websocket: WebSocket):
    """WebSocket endpoint to create a new session"""
    await connection_manager.handle_websocket(websocket)

# Simple frontend for testing
@app.get("/test", response_class=HTMLResponse)
async def test_frontend():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>AI Chat Test</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            #chat { border: 1px solid #ccc; padding: 20px; height: 400px; overflow-y: scroll; margin-bottom: 20px; }
            .message { margin: 10px 0; padding: 10px; border-radius: 5px; }
            .user { background: #e3f2fd; }
            .ai { background: #f1f8e9; }
            .system { background: #fff3e0; }
            input { width: 70%; padding: 10px; }
            button { padding: 10px 20px; }
        </style>
    </head>
    <body>
        <h1>AI Chat Test Interface</h1>
        <div id="chat"></div>
        <input type="text" id="message" placeholder="Type your message..." />
        <button onclick="sendMessage()">Send</button>
        <button onclick="startNewSession()">New Session</button>
        
        <script>
            let ws;
            let sessionId = null;
            
            function startNewSession() {
                if (ws) ws.close();
                ws = new WebSocket(`ws://${window.location.host}/ws/session`);
                setupWebSocket();
                addMessage('system', 'Starting new session...');
            }
            
            function setupWebSocket() {
                ws.onopen = () => addMessage('system', 'Connected to server');
                
                ws.onmessage = (event) => {
                    const data = JSON.parse(event.data);
                    if (data.type === 'system' && data.metadata?.session_id) {
                        sessionId = data.metadata.session_id;
                        addMessage('system', `Session ID: ${sessionId}`);
                    } else if (data.type === 'ai_chunk') {
                        addMessage('ai', data.content, true);
                    } else if (data.type === 'ai_response_complete') {
                        document.getElementById('chat').lastChild.classList.remove('streaming');
                    }
                };
                
                ws.onclose = () => addMessage('system', 'Disconnected from server');
                ws.onerror = (error) => addMessage('system', `Error: ${error}`);
            }
            
            function sendMessage() {
                const input = document.getElementById('message');
                const message = input.value.trim();
                if (!message || !ws) return;
                
                addMessage('user', message);
                ws.send(JSON.stringify({ type: 'user_message', content: message }));
                input.value = '';
            }
            
            function addMessage(sender, text, streaming = false) {
                const chat = document.getElementById('chat');
                const div = document.createElement('div');
                div.className = `message ${sender} ${streaming ? 'streaming' : ''}`;
                div.textContent = `${sender}: ${text}`;
                chat.appendChild(div);
                chat.scrollTop = chat.scrollHeight;
            }
            
            // Auto-start session
            window.onload = startNewSession;
            
            // Enter key support
            document.getElementById('message').addEventListener('keypress', (e) => {
                if (e.key === 'Enter') sendMessage();
            });
        </script>
    </body>
    </html>
    """